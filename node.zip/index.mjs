import express from "express";
import cors from "cors";
import mongoose from "mongoose";
import * as dotenv from "dotenv";
import cookieParser from "cookie-parser";
import bodyParser from "body-parser";
import kyc from "./routes/kycForm.mjs";
import login from "./routes/login.mjs";
import getEmployeeDetails from "./routes/getEmployeeDetails.mjs";
import updateKyc from "./routes/updateKyc.mjs";
import getKyc from "./routes/getKyc.mjs";
import approveKyc from "./routes/approveKyc.mjs";
import birthdayMail from "./routes/birthdayMail.mjs";

dotenv.config();
const app = express();
app.use(bodyParser.json({ limit: "100mb" }));
app.use(express.json());
app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
mongoose.set("strictQuery", true);

mongoose
  .connect("mongodb://localhost:27017/kyc", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    app.use(kyc);
    app.use(login);
    app.use(getEmployeeDetails);
    app.use(updateKyc);
    app.use(getKyc);
    app.use(approveKyc);
    app.use(birthdayMail);

    app.listen(9000, () => {
      console.log(`BE started at port 9000`);
    });
  })
  .catch((err) => console.log("Error connecting to MongoDB Atlas:", err));
